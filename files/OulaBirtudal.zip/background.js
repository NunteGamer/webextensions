chrome.webNavigation.onBeforeNavigate.addListener((details) => {
    let url = new URL(details.url);
  
    // Comprobar si la URL contiene el parámetro 'forcedownload=1'
    if (url.searchParams.has("forcedownload") && url.searchParams.get("forcedownload") === "1") {
      // Eliminar el parámetro 'forcedownload'
      url.searchParams.delete("forcedownload");
  
      // Redirigir la pestaña a la nueva URL
      chrome.tabs.update(details.tabId, { url: url.toString() });
    }
  }, {
    url: [{ urlMatches: 'https://*/*' }, { urlMatches: 'http://*/*' }]
  });
  